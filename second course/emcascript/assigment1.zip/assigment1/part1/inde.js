let str="good morning children";
console.log( "the teacher wishes" + " " + str);
